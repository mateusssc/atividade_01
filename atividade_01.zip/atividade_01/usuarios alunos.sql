create database if not exists db_usuario;
use db_usuario;

create table usuarios (
id int primary key auto_increment not null,
nome char (100) not null,
email varchar (100) not null,
senha varchar (150) unique not null, 
data_cadastro timestamp default current_timestamp
);


select * from usuarios;