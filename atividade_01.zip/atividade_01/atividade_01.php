<?php

$host = '127.0.0.1'; 
$dbname = 'db_usuario';
$username = 'root';
$password = '12345';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
      
        $nome = trim($_POST['nome']);
        $email = filter_var(trim($_POST['email']), FILTER_VALIDATE_EMAIL);
        $senha = $_POST['senha'];

        
        if (!preg_match("/^[a-zA-Z\s]+$/", $nome)) {
            echo "Erro: Nome inválido.";
            exit;
        }

      
        if (!$email) {
            echo "Erro: E-mail inválido.";
            exit;
        }

     
        $sql = "SELECT COUNT(*) FROM usuarios WHERE email = :email";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':email', $email);
        $stmt->execute();
        $emailCount = $stmt->fetchColumn();

        if ($emailCount > 0) {
            echo "Erro: E-mail já cadastrado.";
            exit;
        }

        
        $senhaHash = password_hash($senha, PASSWORD_DEFAULT);

        
        $sql = "INSERT INTO usuarios (nome, email, senha) VALUES (:nome, :email, :senha)";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':nome', $nome);
        $stmt->bindParam(':email', $email);
        $stmt->bindParam(':senha', $senhaHash);

        $stmt->execute();
        echo "Usuário cadastrado com sucesso!";
    }
} catch (PDOException $e) {
   
    error_log($e->getMessage());
    echo "Erro: Ocorreu um problema ao cadastrar o usuário.";
}
?>